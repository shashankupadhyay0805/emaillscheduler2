// export default {
//   plugins: {
//     tailwindcss: {},
//     autoprefixer: {},
//   },
// };
// export default {
//   plugins: {
//     "@tailwindcss/postcss": {},
//     autoprefixer: {},
//   },
// };

export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};

